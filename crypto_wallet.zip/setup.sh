#!/bin/bash

# Usage: sudo ./setup.sh example.com
DOMAIN=$1

if [ -z "$DOMAIN" ]; then
  echo "❌ Please provide a domain"
  echo "Usage: sudo ./setup.sh example.com"
  exit 1
fi

echo "🚀 Starting setup for $DOMAIN"

# Kill anything on port 3000
echo "🧨 Killing processes on port 3000..."
sudo lsof -ti:3000 | sudo xargs -r kill -9

# Update system
echo "📦 Updating system..."
sudo apt update -y && sudo apt upgrade -y

# Install essentials
echo "🔧 Installing Node, npm, nginx, certbot..."
sudo apt install -y nodejs npm nginx certbot python3-certbot-nginx

# Install npm deps if package.json exists
if [ -f "package.json" ]; then
  echo "📥 Installing npm dependencies..."
  npm install
else
  echo "⚠️ No package.json found, skipping npm install"
fi

# Nginx config
NGINX_CONF="/etc/nginx/sites-available/$DOMAIN"

echo "🌐 Creating Nginx config..."
sudo tee $NGINX_CONF > /dev/null <<EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

# Enable site
sudo ln -sf $NGINX_CONF /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test & reload nginx
echo "🔄 Reloading Nginx..."
sudo nginx -t && sudo systemctl reload nginx

# SSL
echo "🔐 Requesting SSL certificate..."
sudo certbot --nginx -d $DOMAIN -d www.$DOMAIN --non-interactive --agree-tos -m admin@$DOMAIN


nohup npm run start > log.txt 2>&1 &
echo "✅ Setup complete!"
