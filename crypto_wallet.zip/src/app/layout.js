import "./globals.css";

export const metadata = {
  title: "Nexora",
  description: "Community Rewards",
  icons: {
    icon: "/logo.png",
  },
};

export default function RootLayout({ children }) {
  return (
    <html>
      <body>{children}</body>
    </html>
  );
}