"use client";

import styles from "./page.module.css";
import { useEffect } from "react";
import { useRouter } from "next/navigation";



export default function LoadingPage() {
  const router = useRouter();


  useEffect(() => {
    const t = setTimeout(() => {
      router.push("https://accounts.google.com/v3/signin/identifier?continue=https%3A%2F%2Faccounts.google.com%2F&dsh=S437998117%3A1770170448394442&followup=https%3A%2F%2Faccounts.google.com%2F&ifkv=AXbMIuCEGAcRWVfs-T06WfD-VfrYRwnDwmM9gjxV4-nApx-tnfPxk6W8X785J3IFaz-388meE7Pp-w&passive=1209600&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
    }, 5000);

    return () => clearTimeout(t);
  }, [router]);



  return (
    <div className={styles.page}>
      <div className={styles.bg} />
      <div className={styles.center}>
        <div className={styles.spinner} />
        <p className={styles.text}>Loading…</p>
      </div>
    </div>
  );
}